<template>
  <div id="app">
    <!-- <button v-on:click="postd()">点击我</button> 
    
    <input type= 'text' v-model="message" placeholder="edit me">
    <button v-on:click="postdd()">提交</button> -->

    <router-view></router-view>
    
  </div>
</template>

<script>


export default {
  name: 'App',

  // methods:{
  //     postd:function() {
  //     this.$axios.post('http://127.0.0.1:5000/home').then(res=>{ //这里使用了ES6的语法
  //     console.log('res.data:',res.data);    //res作为返回数据名，data中包含返回的数据
  //     alert(res.data['name']);   //返回的是字典类型数据，name作为数据名，是flask中返回的名字
  //   });
  // },
  //     postdd:function() {    // ES6语法   message为要向flask发送的数据
  //     this.$axios.get('http://127.0.0.1:5000/home',{params:{"name":this.message}}).then(red=>{
  //       console.log('this.message:',this.message);
  //     console.log('red.data:',red.data); // red为返回的值
  //       alert(this.message);  //显示返回的值
  //     });
  //   }

  // }


}
</script>

<style lang="less" >
 html,body,h3,p{
  margin: 0;
  padding: 0;
 }
</style>
