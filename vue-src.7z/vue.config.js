const { defineConfig } = require('@vue/cli-service')
module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave: false,

  // publicPath: './' //标记:1  是否可以本地打开
  publicPath: '/static/',
})
