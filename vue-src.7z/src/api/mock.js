import Mock from 'mockjs'
import homeApi from './mockServeData/home'
import user from './mockServeData/user'
// 定义mock请求拦截
Mock.mock('/api/home/getData',homeApi.getStatisticalData)
// 用户数据列表
Mock.mock('/api/user/getData',user.createUser)

// 用户列表的数据
Mock.mock('/api/user/add','post',user.createUser)
Mock.mock('/api/user/edit','post',user.updateUser)
Mock.mock('/api/user/del','post',user.deleteUser)
Mock.mock(/api\/user\/getUser/,user.getUserList)

