<template>
    <div class="header-container">
        <div class="l-content">
            <!-- 菜单栏隐藏 -->
            <el-button style="margin-right: 20px" @click="handleMenu" icon="el-icon-menu" size="mini"></el-button>

            <!-- 面包屑 -->
            <el-breadcrumb separator=">">
                <el-breadcrumb-item v-for="item in tags" :key="item.path" :to="{ path: item.path }" >{{item.label}}</el-breadcrumb-item>
            </el-breadcrumb>
        </div>
        <div class="r-content">
            <el-dropdown>
                <span class="el-dropdown-link">
                   <img class="user" src="../assets/images/user.png" alt="">
                </span>
                <el-dropdown-menu slot="dropdown">
                    <el-dropdown-item>个人中心</el-dropdown-item>
                    <el-dropdown-item>推出</el-dropdown-item>

                </el-dropdown-menu>
            </el-dropdown>
        </div>        
    </div>
</template>

<script>
import {mapState} from 'vuex'
export default {
    data() {
        return {
            
        }
    },
    methods:{
        handleMenu(){
            // 提交到store/tab,js里的mutations
            this.$store.commit('collapseMenu')
        }
    },
    computed:{
        ...mapState({
            tags:state => state.tab.tabsList 
        })
    },
    mounted(){
        // console.log(this.tags,"tags@@@@")
    }
}
</script>

<style lang="less" scoped>
.header-container{

    background-color: #6c6565;
    height: 60px;
    // 小图标
    display: flex;
    // 主轴上居中
    justify-content: space-between;
    // 纵轴上 垂直居中
    align-items: center;
    // 上下为0 左20
    padding:0 20px;
    .text {
        color: #fff;
        font-size: 14px;
        margin-left: 10px;
    }
    .r-content{
        .user{
            width: 40px;
            height: 40px;
            border-radius: 50%;
        }
    }
    .l-content { 
        display: flex;
        align-items: center;
        /deep/.el-breadcrumb__item {  //样式的穿刺
            .el-breadcrumb__inner{
                font-weight: normal;
                &.is-link { //innne 并且有islink的时候
                     color: #a5a3a3;

                }
            }
            &:last-child {
                .el-breadcrumb__inner {
                    color: #fff;
                }
            }
        }

    }

}
</style>