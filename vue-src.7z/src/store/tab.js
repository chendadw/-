export default {
    state: {
        isCollapse: false, //控制菜单收起
        tabsList:[
            {
                path: "/",
                name: "home",
                label: "首页",
                icon: "s-home",
                url: "Home/Home",
              }
        ] //面包屑数据
    },
    mutations:{
    // 修改菜单收起的方法
    collapseMenu(state){
        state.isCollapse = !state.isCollapse
    },
    // 更新面包屑    val 从comAside中this.$store.commit('selectMenu',item)传进来的数据item
    selectMenu(state,val){
        // console.log('val:',val)
        if (val.name !== 'home') {
            // 如果存在返回数据的索引,不存在则返回-1
            const index = state.tabsList.findIndex(item => item.name === val.name)
            // console.log('index:',index)
            if (index === -1) {
                state.tabsList.push(val)
            }
        }

        },
        // 联合Com.. tag.vue 删除指定的数据  
        closeTage(state,item){
            // console.log('item:',item.name)
            const index = state.tabsList.findIndex(val => val.name === item.name)
            // console.log('index',index)
            // splice 开始删除元素的索引,删除的次数
            state.tabsList.splice(index,1)
        }

    }

}